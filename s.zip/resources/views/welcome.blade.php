@extends('layouts.master')

    @section('content')
    <div class="row">
          <h1 class="text-center">Welcome to GreenMart!</h1>
    </div>
    @endsection
