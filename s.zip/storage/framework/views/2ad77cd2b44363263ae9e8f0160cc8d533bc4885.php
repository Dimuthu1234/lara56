    <?php $__env->startSection('content'); ?>
    <div class="row">
          <h1 class="text-center">Welcome to GreenMart!</h1>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>