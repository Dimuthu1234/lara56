<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-6 col-md-4 col-md-offset-4 col-sm-offset-3">
      <h1>Checkout</h1>
      <h4>Your Total: $<?php echo e($total); ?></h4>
      <div id = "charge-error" class="alert alert-danger <?php echo e(!Session::has('error') ? 'hidden' : ''); ?>">
          <?php echo e(Session::get('error')); ?>

      </div>
      <form class="" action="<?php echo e(route('checkout')); ?>" method="post" id = "checkout-form">
        <?php echo csrf_field(); ?>
          <div class="col-xs-12">
              <div class="form-group">
                <label for="name">Name</label>
                <input type ="text" id ="name" name="name" class ="form-control" required>
              </div>
          </div>

          <div class="col-xs-12">
              <div class="form-group">
                <label for="address">Address</label>
                <input type ="text" id ="address" name="address" class ="form-control" required>
              </div>
          </div>

          <div class="col-xs-12">
              <div class="form-group">
                <label for="card-name">Card Holder Name</label>
                <input type ="text" id ="card-name" class ="form-control" required>
              </div>
          </div>

          <div class="col-xs-12">
              <div class="form-group">
                <label for="card-number">Credit card Number</label>
                <input type ="text" id ="card-number" class ="form-control" required>
              </div>
          </div>

          <div class="col-xs-12">
            <div class="row">
                <div class="col-xs-6">
                  <div class="form-group">
                    <label for="card-expiry-month">Expiration Month</label>
                    <input type ="text" id ="card-expiry-month" class ="form-control" required>
                  </div>
                </div>
                <div class="col-xs-6">
                  <div class="form-group">
                    <label for="card-expiry-year">Expiration Year</label>
                    <input type ="text" id ="card-expiry-year" class ="form-control" required>
                  </div>
                </div>
            </div>
          </div>

          <div class="col-xs-12">
              <div class="form-group">
                <label for="card-cvc">CVC</label>
                <input type ="text" id ="card-cvc" class ="form-control" required>
              </div>
          </div>
          <button type="submit" class="btn btn-primary">Buy now</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://js.stripe.com/v3/"></script>
<script src="<?php echo e(url('js/custom.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>